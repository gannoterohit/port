@extends('admin.layouts.master')

@section('title', 'Dashboard')
@section('header', 'Dashboard')

@section('admin-content')
<div class="space-y-7">
    <section class="flex flex-col gap-4 rounded-2xl border border-[#E5E1D5] bg-gradient-to-br from-white to-[#FAF9F5] p-5 shadow-xs sm:flex-row sm:items-center sm:justify-between sm:p-6">
        <div>
            <p class="text-xs font-mono uppercase tracking-wider text-[#B85D19] font-bold">Welcome back, {{ Auth::user()?->name ?? 'Admin' }}</p>
            <h2 class="mt-1 text-xl font-bold tracking-tight text-stone-900 sm:text-2xl">Portfolio Control &amp; Analytics</h2>
            <p class="mt-1 text-sm text-stone-500">Keep your projects, services, enquiries and resume up to date.</p>
        </div>
        <div class="flex flex-wrap gap-2.5">
            <a href="{{ route('admin.projects.create') }}" class="admin-btn-primary">+ Add Project</a>
            <a href="{{ route('admin.enquiries.index') }}" class="admin-btn-secondary">View Messages</a>
        </div>
    </section>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="admin-stat-card">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-xs font-medium text-stone-500 mb-1 uppercase tracking-wider">Total Projects</p>
                    <p class="text-3xl font-bold text-stone-900">{{ $stats['total_projects'] }}</p>
                </div>
                <div class="w-10 h-10 bg-[#B85D19]/10 rounded-xl flex items-center justify-center border border-[#B85D19]/20">
                    <svg class="w-5 h-5 text-[#B85D19]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11V9a6 6 0 00-6-6H8a6 6 0 00-6 6v6l2 2v4a2 2 0 002 2h8a2 2 0 002-2v-4l2-2z"></path>
                    </svg>
                </div>
            </div>
        </div>

        <div class="admin-stat-card">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500 mb-1">Published Projects</p>
                    <p class="text-3xl font-bold text-green-600">{{ $stats['published_projects'] }}</p>
                </div>
                <div class="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                    <svg class="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="9"></circle>
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m8 12 2.5 2.5L16 9"></path>
                    </svg>
                </div>
            </div>
        </div>

        <div class="admin-stat-card">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500 mb-1">Draft Projects</p>
                    <p class="text-3xl font-bold text-yellow-600">{{ $stats['draft_projects'] }}</p>
                </div>
                <div class="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                    <svg class="w-5 h-5 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 17h2M11 7h2v6h-2zM9 9h6m-3 0l3-3m-3 0L9 9z"></path>
                    </svg>
                </div>
            </div>
        </div>

        <div class="admin-stat-card">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500 mb-1">Total Services</p>
                    <p class="text-3xl font-bold text-gray-900">{{ $stats['total_services'] }}</p>
                </div>
                <div class="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                    <svg class="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 13.27V6a2 2 0 00-2-2H5a2 2 0 010-4c.55 0 1 .45 1 1v2h12a1 1 0 011 1v2.23l-1.5 1.5A3.5 3.5 0 019 13.27V6a3 3 0 013-3h6a3 3 0 013 3v7.27z"></path>
                    </svg>
                </div>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="admin-stat-card">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500 mb-1">Total Enquiries</p>
                    <p class="text-3xl font-bold text-gray-900">{{ $stats['total_enquiries'] }}</p>
                </div>
                <div class="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                    <svg class="w-5 h-5 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 01-2-2v12a2 2 0 002 2z"></path>
                    </svg>
                </div>
            </div>
        </div>

        <div class="admin-stat-card">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500 mb-1">New Enquiries</p>
                    <p class="text-3xl font-bold text-emerald-700">{{ $stats['new_enquiries'] }}</p>
                </div>
                <div class="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center">
                    <svg class="w-5 h-5 text-emerald-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                </div>
            </div>
        </div>

        <div class="admin-stat-card">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500 mb-1">Unread Enquiries</p>
                    <p class="text-3xl font-bold text-red-600">{{ $stats['unread_enquiries'] }}</p>
                </div>
                <div class="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                    <svg class="w-5 h-5 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.983 3C6.45 4.15 2 9.05 2 15v5l3-3 7-1 7 1 7 3v-5c0-5.95-4.45-10.85-10-12z"></path>
                    </svg>
                </div>
            </div>
        </div>

        <div class="admin-stat-card">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-xs font-medium text-stone-500 mb-1 uppercase tracking-wider">Active Skills</p>
                    <p class="text-3xl font-bold text-stone-900">{{ $stats['total_skills'] }}</p>
                </div>
                <div class="w-10 h-10 bg-[#B85D19]/10 rounded-xl flex items-center justify-center border border-[#B85D19]/20">
                    <svg class="w-5 h-5 text-[#B85D19]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4"></path>
                    </svg>
                </div>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="admin-card overflow-hidden">
            <div class="border-b border-gray-100 px-5 py-4">
                <h2 class="text-base font-semibold text-gray-900">Recent enquiries</h2>
                <p class="mt-0.5 text-xs text-gray-500">Latest messages from your contact form</p>
            </div>
            <div class="divide-y divide-gray-100">
                @forelse($recentEnquiries as $enquiry)
                    <div class="p-4 hover:bg-gray-50 transition-colors">
                        <div class="flex items-start justify-between">
                            <div>
                                <p class="font-medium text-gray-900">{{ $enquiry->name }}</p>
                                <p class="text-sm text-gray-500">{{ $enquiry->email }}</p>
                                <p class="text-sm text-gray-600 mt-1 line-clamp-2">{{ Str::limit($enquiry->message, 80) }}</p>
                                <p class="text-xs text-gray-400 mt-1">{{ $enquiry->created_at->diffForHumans() }}</p>
                            </div>
                            @php
                                $statusClasses = [
                                    'new' => 'bg-emerald-100 text-emerald-900',
                                    'in_progress' => 'bg-amber-100 text-amber-800',
                                    'contacted' => 'bg-emerald-100 text-emerald-800',
                                    'converted' => 'bg-purple-100 text-purple-800',
                                    'closed' => 'bg-slate-100 text-slate-800',
                                ];
                            @endphp
                            <span class="px-2.5 py-1 text-xs font-semibold rounded-full {{ $statusClasses[$enquiry->status] ?? 'bg-gray-100 text-gray-800' }}">
                                {{ $enquiry->status_label }}
                            </span>
                        </div>
                    </div>
                @empty
                    <div class="p-4 text-center text-gray-500">No enquiries yet.</div>
                @endforelse
            </div>
            @if($recentEnquiries->count())
                <div class="p-3 border-t border-gray-200">
                    <a href="{{ route('admin.enquiries.index') }}" class="text-sm text-emerald-700 hover:text-emerald-800">View all enquiries</a>
                </div>
            @endif
        </div>

        <div class="admin-card overflow-hidden">
            <div class="border-b border-gray-100 px-5 py-4">
                <h2 class="text-base font-semibold text-gray-900">Recent projects</h2>
                <p class="mt-0.5 text-xs text-gray-500">Recently added to your portfolio</p>
            </div>
            <div class="divide-y divide-gray-100">
                @forelse($recentProjects as $project)
                    <div class="p-4 hover:bg-gray-50 transition-colors">
                        <div class="flex items-start gap-3">
                            <div class="w-10 h-10 bg-gray-200 rounded-lg flex-shrink-0">
                                @if($project->thumbnail)
                                    <img src="{{ $project->thumbnail_url }}" alt="{{ $project->title }}" class="w-10 h-10 object-cover rounded-lg">
                                @endif
                            </div>
                            <div class="flex-1">
                                <p class="font-medium text-gray-900">{{ $project->title }}</p>
                                @php
                                    $projectStatusClasses = $project->status === 'published'
                                        ? 'bg-emerald-100 text-emerald-800'
                                        : 'bg-amber-100 text-amber-800';
                                @endphp
                                <span class="rounded-full px-2 py-1 text-xs {{ $projectStatusClasses }}">
                                    {{ $project->status_label }}
                                </span>
                                <p class="text-xs text-gray-400 mt-1">{{ $project->created_at->diffForHumans() }}</p>
                            </div>
                        </div>
                    </div>
                @empty
                    <div class="p-4 text-center text-gray-500">No projects yet.</div>
                @endforelse
            </div>
            @if($recentProjects->count())
                <div class="p-3 border-t border-gray-200">
                    <a href="{{ route('admin.projects.index') }}" class="text-sm text-emerald-700 hover:text-emerald-800">View all projects</a>
                </div>
            @endif
        </div>
    </div>
</div>
@endsection
